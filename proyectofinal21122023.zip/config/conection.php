<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "app";

$conn = new mysqli($host, $user, $pass, $db);

?>
